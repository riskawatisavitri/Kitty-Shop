<?php
/**
 * The list of icons
 *
 * @package ThemeHunk
 */
?>
<div class="iconpicker-popover popover bottomLeft">
	<div class="arrow"></div>
	<div class="popover-title">
		<input type="search" class="form-control iconpicker-search" placeholder="Type to filter">
	</div>
	<div class="popover-content">
		<div class="iconpicker">
			<div class="iconpicker-items">

				<i data-type="iconpicker-item" title=".fa-behance" class="fa fa-behance"></i>
				<i data-type="iconpicker-item" title=".fa-behance-square" class="fa fa-behance-square"></i>
				<i data-type="iconpicker-item" title=".fa-facebook" class="fa fa-facebook"></i>
				<i data-type="iconpicker-item" title=".fa-facebook-square" class="fa fa-facebook-square"></i>
				<i data-type="iconpicker-item" title=".fa-google-plus" class="fa fa-google-plus"></i>
				<i data-type="iconpicker-item" title=".fa-google-plus-square" class="fa fa-google-plus-square"></i>
				<i data-type="iconpicker-item" title=".fa-linkedin" class="fa fa-linkedin"></i>
				<i data-type="iconpicker-item" title=".fa-linkedin-square" class="fa fa-linkedin-square"></i>
				<i data-type="iconpicker-item" title=".fa-twitter" class="fa fa-twitter"></i>
				<i data-type="iconpicker-item" title=".fa-twitter-square" class="fa fa-twitter-square"></i>
				<i data-type="iconpicker-item" title=".fa-vimeo" class="fa fa-vimeo"></i>
				<i data-type="iconpicker-item" title=".fa-vimeo-square" class="fa fa-vimeo-square"></i>
				<i data-type="iconpicker-item" title=".fa-youtube" class="fa fa-youtube"></i>
				<i data-type="iconpicker-item" title=".fa-youtube-square" class="fa fa-youtube-square"></i>
				<i data-type="iconpicker-item" title=".fa-ambulance" class="fa fa-ambulance"></i>
				<i data-type="iconpicker-item" title=".fa-american-sign-language-interpreting" class="fa fa-american-sign-language-interpreting"></i>
				<i data-type="iconpicker-item" title=".fa-anchor" class="fa fa-anchor"></i>
				<i data-type="iconpicker-item" title=".fa-android" class="fa fa-android"></i>
				<i data-type="iconpicker-item" title=".fa-apple" class="fa fa-apple"></i>
				<i data-type="iconpicker-item" title=".fa-archive" class="fa fa-archive"></i>
				<i data-type="iconpicker-item" title=".fa-area-chart" class="fa fa-area-chart"></i>
				<i data-type="iconpicker-item" title=".fa-asterisk" class="fa fa-asterisk"></i>
				<i data-type="iconpicker-item" title=".fa-automobile" class="fa fa-automobile"></i>
				<i data-type="iconpicker-item" title=".fa-balance-scale" class="fa fa-balance-scale"></i>
				<i data-type="iconpicker-item" title=".fa-ban" class="fa fa-ban"></i>
				<i data-type="iconpicker-item" title=".fa-bank" class="fa fa-bank"></i>
				<i data-type="iconpicker-item" title=".fa-bicycle" class="fa fa-bicycle"></i>
				<i data-type="iconpicker-item" title=".fa-birthday-cake" class="fa fa-birthday-cake"></i>
				<i data-type="iconpicker-item" title=".fa-btc" class="fa fa-btc"></i>
				<i data-type="iconpicker-item" title=".fa-black-tie" class="fa fa-black-tie"></i>
				<i data-type="iconpicker-item" title=".fa-bookmark" class="fa fa-bookmark"></i>
				<i data-type="iconpicker-item" title=".fa-briefcase" class="fa fa-briefcase"></i>
				<i data-type="iconpicker-item" title=".fa-bus" class="fa fa-bus"></i>
				<i data-type="iconpicker-item" title=".fa-cab" class="fa fa-cab"></i>
				<i data-type="iconpicker-item" title=".fa-camera" class="fa fa-camera"></i>
				<i data-type="iconpicker-item" title=".fa-check" class="fa fa-check"></i>
				<i data-type="iconpicker-item" title=".fa-child" class="fa fa-child"></i>
				<i data-type="iconpicker-item" title=".fa-code" class="fa fa-code"></i>
				<i data-type="iconpicker-item" title=".fa-coffee" class="fa fa-coffee"></i>
				<i data-type="iconpicker-item" title=".fa-cog" class="fa fa-cog"></i>
				<i data-type="iconpicker-item" title=".fa-commenting" class="fa fa-commenting"></i>
				<i data-type="iconpicker-item" title=".fa-cube" class="fa fa-cube"></i>
				<i data-type="iconpicker-item" title=".fa-dollar" class="fa fa-dollar"></i>
				<i data-type="iconpicker-item" title=".fa-diamond" class="fa fa-diamond"></i>
				<i data-type="iconpicker-item" title=".fa-envelope" class="fa fa-envelope"></i>
				<i data-type="iconpicker-item" title=".fa-female" class="fa fa-female"></i>
				<i data-type="iconpicker-item" title=".fa-fire-extinguisher" class="fa fa-fire-extinguisher"></i>
				<i data-type="iconpicker-item" title=".fa-glass" class="fa fa-glass"></i>
				<i data-type="iconpicker-item" title=".fa-globe" class="fa fa-globe"></i>
				<i data-type="iconpicker-item" title=".fa-graduation-cap" class="fa fa-graduation-cap"></i>
				<i data-type="iconpicker-item" title=".fa-heartbeat" class="fa fa-heartbeat"></i>
				<i data-type="iconpicker-item" title=".fa-heart" class="fa fa-heart"></i>
				<i data-type="iconpicker-item" title=".fa-hotel" class="fa fa-hotel"></i>
				<i data-type="iconpicker-item" title=".fa-hourglass" class="fa fa-hourglass"></i>
				<i data-type="iconpicker-item" title=".fa-home" class="fa fa-home"></i>
				<i data-type="iconpicker-item" title=".fa-hourglass" class="fa fa-hourglass"></i>
				<i data-type="iconpicker-item" title=".fa-legal" class="fa fa-legal"></i>
				<i data-type="iconpicker-item" title=".fa-lock" class="fa fa-lock"></i>
				<i data-type="iconpicker-item" title=".fa-map-signs" class="fa fa-map-signs"></i>
				<i data-type="iconpicker-item" title=".fa-paint-brush" class="fa fa-paint-brush"></i>
				<i data-type="iconpicker-item" title=".fa-plane" class="fa fa-plane"></i>
				<i data-type="iconpicker-item" title=".fa-rocket" class="fa fa-rocket"></i>
				<i data-type="iconpicker-item" title=".fa-puzzle-piece" class="fa fa-puzzle-piece"></i>
				<i data-type="iconpicker-item" title=".fa-shield" class="fa fa-shield"></i>
				<i data-type="iconpicker-item" title=".fa-tag" class="fa fa-tag"></i>
				<i data-type="iconpicker-item" title=".fa-times" class="fa fa-times"></i>
				<i data-type="iconpicker-item" title=".fa-unlock" class="fa fa-unlock"></i>
				<i data-type="iconpicker-item" title=".fa-user" class="fa fa-user"></i>
				<i data-type="iconpicker-item" title=".fa-user" class="fa fa-user"></i>
				<i data-type="iconpicker-item" title=".fa-user-md" class="fa fa-user-md"></i>
				<i data-type="iconpicker-item" title=".fa-video-camera" class="fa fa-video-camera"></i>
				<i data-type="iconpicker-item" title=".fa-wordpress" class="fa fa-wordpress"></i>
				<i data-type="iconpicker-item" title=".fa-wrench" class="fa fa-wrench"></i>
				<i data-type="iconpicker-item" title=".fa-youtube-play" class="fa fa-youtube-play"></i>

			</div> <!-- /.iconpicker-items -->
		</div> <!-- /.iconpicker -->
	</div> <!-- /.popover-content -->
</div> <!-- /.iconpicker-popover -->
