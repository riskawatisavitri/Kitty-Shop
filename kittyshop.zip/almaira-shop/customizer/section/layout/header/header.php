<?php
/**
 * Header Options for  Almaira Shop Theme.
* @package ThemeHunk
 * @subpackage Almaira Shop
 * @since 1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'almaira-shop-section-header-group';
$wp_customize->get_control( 'header_image' )->priority = 1;
